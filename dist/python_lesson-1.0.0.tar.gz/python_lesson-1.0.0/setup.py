from distutils.core import setup

setup(
    name='python_lesson',
    version='1.0.0',
    package=['lesson_package', 'lesson_package.talk'],
    url='',
    license='Free',
    author='yuta',
    author_email='',
    description='Sample package'
)
